function toggle(element) {
    if (element.nextElementSibling.nextElementSibling.style.visibility == "hidden"){
    element.nextElementSibling.nextElementSibling.style.visibility = "visible";
    element.nextElementSibling.selectedIndex = "0";
    } else {element.nextElementSibling.nextElementSibling.style.visibility = "hidden"}
}
